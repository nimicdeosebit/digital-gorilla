"""Digital Gorilla four-actor power simulation."""
